## Change Summary
- What is changing and why?

## Risk & Approvals
- **Change-Request-ID:** <!-- e.g., CAB-1234 -->
- **Risk:** <!-- Low | Medium | High -->
- **Testing Evidence:** <!-- link logs/screenshots -->

## Checklist
- [ ] CODEOWNERS will review
- [ ] CI checks green
- [ ] Linked Issues (if any)
